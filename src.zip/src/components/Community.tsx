import React from "react";

export default function Community() {
  return <div></div>;
}
