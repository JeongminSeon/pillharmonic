import React from "react";
import styled from "@emotion/styled";

const Nav = styled.nav``;

export default function Footer() {
  return <Nav>Footer</Nav>;
}
